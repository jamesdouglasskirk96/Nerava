"""Domain layer package for canonical IDs and schemas."""


