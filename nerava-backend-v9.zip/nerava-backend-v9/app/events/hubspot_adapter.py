"""
HubSpot event adapter

Maps internal domain events to HubSpot API payloads.
"""
from typing import Dict, Any, Optional
from datetime import datetime
from ..events.domain import (
    DomainEvent,
    DriverSignedUpEvent,
    WalletPassInstalledEvent,
    NovaEarnedEvent,
    NovaRedeemedEvent,
    FirstRedemptionCompletedEvent
)


def to_hubspot_external_id(user_id: int) -> str:
    """
    Convert internal user_id to HubSpot external ID.
    
    Uses deterministic format: "user_{user_id}"
    """
    return f"user_{user_id}"


def adapt_driver_signed_up(event: DriverSignedUpEvent, email: Optional[str] = None) -> Dict[str, Any]:
    """
    Adapt driver_signed_up event to HubSpot contact + event.
    
    Returns tuple of (contact_properties, event_name, event_properties)
    """
    contact_properties = {
        "email": email or event.email,
        "hs_lead_status": "NEW",
        "lifecyclestage": "customer",
        "createdate": event.created_at.isoformat() if event.created_at else datetime.utcnow().isoformat(),
    }
    
    # Add auth provider if available
    if event.auth_provider:
        contact_properties["auth_provider"] = event.auth_provider
    
    event_name = "driver_signed_up"
    event_properties = {
        "email": email or event.email,
        "auth_provider": event.auth_provider or "unknown",
        "signed_up_at": event.created_at.isoformat() if event.created_at else datetime.utcnow().isoformat()
    }
    
    return {
        "contact_properties": contact_properties,
        "event_name": event_name,
        "event_properties": event_properties
    }


def adapt_wallet_pass_installed(event: WalletPassInstalledEvent, email: Optional[str] = None) -> Dict[str, Any]:
    """Adapt wallet_pass_installed event to HubSpot event"""
    event_name = "wallet_pass_installed"
    event_properties = {
        "pass_type": event.pass_type,
        "installed_at": event.installed_at.isoformat() if event.installed_at else datetime.utcnow().isoformat()
    }
    
    return {
        "event_name": event_name,
        "event_properties": event_properties
    }


def adapt_nova_earned(event: NovaEarnedEvent, email: Optional[str] = None) -> Dict[str, Any]:
    """Adapt nova_earned event to HubSpot event"""
    event_name = "nova_earned"
    event_properties = {
        "amount_cents": event.amount_cents,
        "new_balance_cents": event.new_balance_cents,
        "earned_at": event.earned_at.isoformat() if event.earned_at else datetime.utcnow().isoformat()
    }
    
    if event.session_id:
        event_properties["session_id"] = event.session_id
    
    return {
        "event_name": event_name,
        "event_properties": event_properties
    }


def adapt_nova_redeemed(event: NovaRedeemedEvent, email: Optional[str] = None) -> Dict[str, Any]:
    """Adapt nova_redeemed event to HubSpot event"""
    event_name = "nova_redeemed"
    event_properties = {
        "amount_cents": event.amount_cents,
        "merchant_id": event.merchant_id,
        "redemption_id": event.redemption_id,
        "new_balance_cents": event.new_balance_cents,
        "redeemed_at": event.redeemed_at.isoformat() if event.redeemed_at else datetime.utcnow().isoformat()
    }
    
    return {
        "event_name": event_name,
        "event_properties": event_properties
    }


def adapt_first_redemption_completed(event: FirstRedemptionCompletedEvent, email: Optional[str] = None) -> Dict[str, Any]:
    """Adapt first_redemption_completed event to HubSpot event"""
    event_name = "first_redemption_completed"
    event_properties = {
        "redemption_id": event.redemption_id,
        "merchant_id": event.merchant_id,
        "amount_cents": event.amount_cents,
        "completed_at": event.completed_at.isoformat() if event.completed_at else datetime.utcnow().isoformat()
    }
    
    return {
        "event_name": event_name,
        "event_properties": event_properties
    }


def adapt_event_to_hubspot(
    event: DomainEvent,
    email: Optional[str] = None
) -> Optional[Dict[str, Any]]:
    """
    Adapt a domain event to HubSpot payload.
    
    Returns dict with:
    - contact_properties: Optional dict for contact upsert
    - event_name: Event name
    - event_properties: Event properties
    
    Returns None if event type is not supported.
    """
    if isinstance(event, DriverSignedUpEvent):
        return adapt_driver_signed_up(event, email)
    elif isinstance(event, WalletPassInstalledEvent):
        return adapt_wallet_pass_installed(event, email)
    elif isinstance(event, NovaEarnedEvent):
        return adapt_nova_earned(event, email)
    elif isinstance(event, NovaRedeemedEvent):
        return adapt_nova_redeemed(event, email)
    elif isinstance(event, FirstRedemptionCompletedEvent):
        return adapt_first_redemption_completed(event, email)
    else:
        return None


