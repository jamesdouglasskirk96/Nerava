# LEGACY: This file has been moved to app/dependencies/__init__.py
# Import from new location for backward compatibility
from .dependencies import get_db

__all__ = ["get_db"]
