"""
HubSpot integration service (log-only mode)

This service handles HubSpot API interactions. By default, it operates in log-only
mode where all payloads are logged but no HTTP requests are made. To enable live
requests, set HUBSPOT_ENABLED=true and HUBSPOT_SEND_LIVE=true.
"""
import json
import logging
from typing import Dict, Any, Optional
from ..core.config import settings

logger = logging.getLogger(__name__)


class HubSpotClient:
    """Client for HubSpot API interactions"""
    
    def __init__(self):
        self.enabled = settings.HUBSPOT_ENABLED
        self.send_live = settings.HUBSPOT_SEND_LIVE
        self.token = settings.HUBSPOT_PRIVATE_APP_TOKEN
        self.portal_id = settings.HUBSPOT_PORTAL_ID
        self.base_url = "https://api.hubapi.com"
    
    def log_payload(self, kind: str, payload: Dict[str, Any]) -> None:
        """
        Always log payloads (sanitized) regardless of enabled state.
        
        Args:
            kind: Type of operation (e.g., "event", "contact")
            payload: Payload data (will be sanitized before logging)
        """
        # Sanitize payload - remove sensitive data
        sanitized = self._sanitize_payload(payload.copy())
        
        logger.info(
            f"[HubSpot {kind}] Payload: {json.dumps(sanitized, default=str)}",
            extra={
                "hubspot_kind": kind,
                "hubspot_payload": sanitized,
                "hubspot_enabled": self.enabled,
                "hubspot_send_live": self.send_live
            }
        )
    
    def _sanitize_payload(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """Remove sensitive data from payload for logging"""
        sanitized = payload.copy()
        # Remove token if present
        sanitized.pop("token", None)
        sanitized.pop("private_app_token", None)
        # Truncate long strings
        for key, value in sanitized.items():
            if isinstance(value, str) and len(value) > 200:
                sanitized[key] = value[:200] + "..."
        return sanitized
    
    def send_event(
        self,
        event_name: str,
        properties: Dict[str, Any],
        email: str,
        external_id: str
    ) -> None:
        """
        Send a custom event to HubSpot.
        
        Args:
            event_name: Name of the event
            properties: Event properties
            email: User email
            external_id: External user ID (e.g., "user_123")
        """
        payload = {
            "eventName": event_name,
            "email": email,
            "properties": properties,
            "externalId": external_id
        }
        
        # Always log
        self.log_payload("event", payload)
        
        # Only send HTTP request if send_live is enabled
        # if self.send_live and self.enabled:
        #     try:
        #         import requests
        #         url = f"{self.base_url}/events/v3/send"
        #         headers = {
        #             "Authorization": f"Bearer {self.token}",
        #             "Content-Type": "application/json"
        #         }
        #         response = requests.post(url, json=payload, headers=headers, timeout=10)
        #         response.raise_for_status()
        #         logger.info(f"[HubSpot] Event sent successfully: {event_name}")
        #     except Exception as e:
        #         logger.error(f"[HubSpot] Failed to send event {event_name}: {e}", exc_info=True)
        #         raise
        # else:
        #     logger.debug(f"[HubSpot] Event not sent (send_live={self.send_live}, enabled={self.enabled}): {event_name}")
    
    def upsert_contact(
        self,
        email: str,
        properties: Dict[str, Any],
        external_id: str
    ) -> None:
        """
        Create or update a contact in HubSpot.
        
        Args:
            email: Contact email
            properties: Contact properties
            external_id: External user ID (e.g., "user_123")
        """
        payload = {
            "email": email,
            "properties": properties,
            "externalId": external_id
        }
        
        # Always log
        self.log_payload("contact", payload)
        
        # Only send HTTP request if send_live is enabled
        # if self.send_live and self.enabled:
        #     try:
        #         import requests
        #         url = f"{self.base_url}/crm/v3/objects/contacts"
        #         headers = {
        #             "Authorization": f"Bearer {self.token}",
        #             "Content-Type": "application/json"
        #         }
        #         # HubSpot uses PATCH for upsert by email
        #         response = requests.patch(
        #             url,
        #             json=payload,
        #             headers=headers,
        #             params={"idProperty": "email"},
        #             timeout=10
        #         )
        #         response.raise_for_status()
        #         logger.info(f"[HubSpot] Contact upserted successfully: {email}")
        #     except Exception as e:
        #         logger.error(f"[HubSpot] Failed to upsert contact {email}: {e}", exc_info=True)
        #         raise
        # else:
        #     logger.debug(f"[HubSpot] Contact not upserted (send_live={self.send_live}, enabled={self.enabled}): {email}")


# Global client instance
hubspot_client = HubSpotClient()


