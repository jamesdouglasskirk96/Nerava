"""External API integrations for While You Charge feature"""

