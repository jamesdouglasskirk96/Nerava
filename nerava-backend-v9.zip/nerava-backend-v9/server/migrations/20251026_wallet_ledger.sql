-- Migration: Drop old wallet_events table
-- Date: 2025-10-26

DROP TABLE IF EXISTS wallet_events;
